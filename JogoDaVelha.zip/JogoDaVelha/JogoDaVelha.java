public class JogoDaVelha {

    public static void main(String[] args) {
        Jogo jogo = new Jogo();
        
        
    }
    
    
}